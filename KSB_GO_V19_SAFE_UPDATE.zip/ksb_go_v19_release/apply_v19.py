#!/usr/bin/env python3
"""KSB GO V19 guarded source patch. Never deploys or edits any live Google data.
Usage: python apply_v19.py /path/to/ksb_go_marketplace
"""
from pathlib import Path
import sys, shutil, tempfile, subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'src'

def replace_once(text, old, new, label):
    hits = text.count(old)
    if hits != 1:
        raise ValueError(f'{label}: expected 1 match, got {hits}; repository may have changed. NO FILES MODIFIED.')
    return text.replace(old, new, 1)

def transform(files):
    def change(file, old, new):
        files[file] = replace_once(files[file], old, new, file)

    change('src/Setup.gs', "  NOTIFICATIONS:'id,user_id,title,message,is_read,created_at',",
           "  WA_OUTBOX_V19:'id,event_type,entity_id,user_id,phone,param1,param2,status,attempts,provider_id,last_error,created_at,updated_at',\n"
           "  WA_OPT_INS_V19:'id,user_id,enabled,updated_at',\n"
           "  NOTIFICATIONS:'id,user_id,title,message,is_read,created_at',")

    change('src/Code.gs', "'ReconciliationUIV11','OperationsUIV15','Scripts'",
           "'ReconciliationUIV11','OperationsUIV15','PurchaseV19','Scripts'")
    change('src/Code.gs', "'market.favorites':ksbMarketFavoriteList_",
           "'notify.optin.get':ksbV19OptInGet_,'notify.optin.set':ksbV19OptInSet_,\n       'market.favorites':ksbMarketFavoriteList_")

    change('src/CommerceV10.gs', "'auth.login','auth.otp.start','auth.otp.verify'",
           "'notify.optin.get','notify.optin.set','auth.login','auth.otp.start','auth.otp.verify'")
    change('src/Code.gs', "    'auth.login','auth.otp.start','auth.otp.verify'",
           "    'notify.optin.get','notify.optin.set','auth.login','auth.otp.start','auth.otp.verify'")

    change('src/Index.html', "<?!= include_('Scripts'); ?>",
           "<?!= include_('PurchaseV19'); ?><?!= include_('Scripts'); ?>")
    change('src/MarketplaceUIV4.html',
           'data-action="marketCardBuy" data-id="${KSB.h(p.id)}">Beli',
           'data-action="marketCardBuy" data-id="${KSB.h(p.id)}" ${Number(p.stock)<=0?\'disabled aria-disabled="true" title="Stok habis"\':\'\'}>Beli')
    change('src/MarketplaceUIV4.html',
           'data-action="buyNow" data-id="${KSB.h(p.id)}" type="button">Beli Langsung',
           'data-action="buyNow" data-id="${KSB.h(p.id)}" type="button" ${Number(p.stock)<=0?\'disabled aria-disabled="true" title="Stok habis"\':\'\'}>Beli Langsung')
    change('src/Buyer.html',
           'class="btn full" data-action="checkoutPage">Checkout',
           'class="btn full" data-action="checkoutPage" ${!s.config?.checkoutEnabled?\'disabled title="Checkout belum aktif"\':\'\'}>Checkout')
    change('src/Buyer.html',
           'data-action="buyNow" data-id="${KSB.h(p.id)}">Beli Sekarang',
           'data-action="buyNow" data-id="${KSB.h(p.id)}" ${Number(p.stock)<=0?\'disabled aria-disabled="true" title="Stok habis"\':\'\'}>Beli Sekarang')
    change('src/Buyer.html',
           'data-action="addCart" data-id="${KSB.h(p.id)}">🛒 + Keranjang',
           'data-action="addCart" data-id="${KSB.h(p.id)}" ${Number(p.stock)<=0?\'disabled aria-disabled="true" title="Stok habis"\':\'\'}>🛒 + Keranjang')

    # Legacy cart handlers remain as fallback; V19 buy-now handlers enforce validations.

    # Notification must occur after successful payment verification, outside the transaction lock.
    change('src/Payments.gs',
           "ksbRole_(actor,'ADMIN');return ksbWithLock_(function(){",
           "ksbRole_(actor,'ADMIN');var result=ksbWithLock_(function(){")
    change('src/Payments.gs',
           "return {status:'VERIFIED'};});}",
           "return {status:'VERIFIED'};});\n"
           "  if(result&&result.status==='VERIFIED')ksbV19SafeQueue_(function(){ksbV19NotifySellerPayment_(args.paymentId);});\n"
           "  return result;}")

    # Courier broadcast only after seller explicitly prepares the parcel (READY).
    change('src/Sellers.gs',
           "var next=String(args.status);return ksbWithLock_(function(){",
           "var next=String(args.status);var result=ksbWithLock_(function(){")
    change('src/Sellers.gs',
           "return {id:so.id,status:next};});}",
           "return {id:so.id,status:next};});\n"
           "  if(result&&result.status==='READY')ksbV19SafeQueue_(function(){ksbV19NotifyCourierReady_(args.id);});\n"
           "  return result;}")

    # Notify admin once after an idempotent settlement claim is committed.
    change('src/ManualClaimsV7.gs',
           "return ksbIdempotent_(actor,'MANUAL_CLAIM_V7',args.requestKey,function(){",
           "var result=ksbIdempotent_(actor,'MANUAL_CLAIM_V7',args.requestKey,function(){")
    change('src/ManualClaimsV7.gs',
           "return {id:id,total:total,status:'PENDING',orders:wanted.length};\n });",
           "return {id:id,total:total,status:'PENDING',orders:wanted.length};\n });\n"
           " ksbV19SafeQueue_(function(){ksbV19NotifyAdminClaim_(result.id);});\n return result;")

    # Bank details remain server-controlled and shown only in transfer checkout.
    change('src/Buyer.html',
           '<div class="notice warn">Pastikan admin telah mengaktifkan Routes API atau menetapkan tarif zona.',
           '${s.config.bankNumber&&s.config.bankName?`<div class="notice"><strong>Rekening transfer resmi KSB GO</strong><div>${KSB.h(s.config.bankName)} · ${KSB.h(s.config.bankNumber)}</div><div>a.n. ${KSB.h(s.config.bankHolder)}</div><small>Bayar hanya setelah pesanan dibuat dan pastikan nomor tujuan cocok. Pembayaran belum sah sebelum diverifikasi admin.</small></div>`:\'\'}<div class="notice warn">Pastikan admin telah mengaktifkan Routes API atau menetapkan tarif zona.')

    files['src/NotificationsV19.gs']=(SOURCE/'NotificationsV19.gs').read_text(encoding='utf-8')
    files['src/PurchaseV19.html']=(SOURCE/'PurchaseV19.html').read_text(encoding='utf-8')
    files['tests/v19.test.cjs']=(ROOT/'tests/v19.test.cjs').read_text(encoding='utf-8')
    return files

def main():
    if len(sys.argv)!=2:
        print('Usage: python apply_v19.py /path/to/ksb_go_marketplace')
        return 2
    repo=Path(sys.argv[1]).expanduser().resolve()
    targets=['src/Setup.gs','src/Code.gs','src/CommerceV10.gs','src/Index.html',
             'src/MarketplaceUIV4.html','src/Payments.gs','src/Sellers.gs',
             'src/ManualClaimsV7.gs','src/Buyer.html']
    if not (repo/'package.json').exists() or not all((repo/x).exists() for x in targets):
        print('ERROR: Bukan direktori source KSB GO yang sesuai. Tidak ada perubahan.')
        return 2
    content={x:(repo/x).read_text(encoding='utf-8') for x in targets}
    if (repo/'src/NotificationsV19.gs').exists():
        print('V19 already present. No changes applied; manually compare before retrying.')
        return 2
    try:
        patched=transform(content)
    except Exception as e:
        print('STOP - '+str(e))
        return 2
    with tempfile.TemporaryDirectory() as td:
        staged=Path(td)
        for name,data in patched.items():
            p=staged/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data,encoding='utf-8')
        # Syntax check all newly modified files locally before touching repository.
        cmd=['node','-e', 'const fs=require("fs"),vm=require("vm");const files=process.argv.slice(1);for(const f of files){let x=fs.readFileSync(f,"utf8");if(f.endsWith(".html")){for(const m of x.matchAll(/<script\\b[^>]*>([\\s\\S]*?)<\\/script\\s*>/gi))new vm.Script(m[1]);}else if(f.endsWith(".gs")){new vm.Script(x);} }']
        filenames=[str(staged/x) for x in patched if x.endswith(('.gs','.html')) and x!='src/Index.html']
        # Index.html contains Apps Script template expressions outside JS; npm test will validate it in the full repository.
        chk=subprocess.run(cmd+filenames,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        if chk.returncode:
            print('STOP: JS syntax check failed, no files modified.\n'+chk.stderr[:2500]);return 2
        for name in patched:
            target=repo/name;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(staged/name,target)
    print('PATCH V19 APPLIED. No deployment performed.')
    print('NEXT: npm test, audit staging, confirm Whatsapp template + bank, then commit as a PR.')
    return 0

if __name__=='__main__':raise SystemExit(main())
