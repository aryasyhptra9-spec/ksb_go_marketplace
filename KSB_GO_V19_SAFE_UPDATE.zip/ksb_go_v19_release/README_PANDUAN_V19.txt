KSB GO V19 — PAKET REVISI TERJAGA
Tanggal: 26 Oktober 2026
Target repository: https://github.com/aryasyhptra9-spec/ksb_go_marketplace
Target sumber: V17.2 pada branch main, BUKAN V18 yang sudah dipasang.

STATUS RIIL
- Patch ini disiapkan dari audit file proyek GitHub, TIDAK dipasang pada GitHub oleh ChatGPT (izin 403).
- Diuji dengan simulasi lokal untuk keamanan kode dan notifikasi. Ini BUKAN jaminan tanpa bug.
- Tidak ada perubahan rekening, pesanan, database, deployment, atau token milik Anda saat ZIP dibuat.
- Jangan menerima pembayaran nyata sampai izin usaha, kontrol dana, dan alur refund/settlement diverifikasi.

APA YANG DIREVISI
1. Tombol Beli pada kartu katalog / detail, kuantitas benar saat Beli Sekarang,
   penanganan stok habis, nonaktif ketika checkout belum diizinkan backend, dan double-click guard.
2. Pengaturan terkontrol BCA 0561934877, pemilik Arya Syah Putra (leading zero tidak hilang).
   Rekening hanya terlihat ketika konfigurasi commerce LIVE benar-benar lulus pemeriksaan server.
3. Notifikasi WA Business Cloud API seller hanya setelah pembayaran sah/verified.
4. Notifikasi kurir setelah status READY/AVAILABLE; hanya verified-online dan opt-in.
5. Notifikasi admin saat seller/kurir membuat klaim payout PENDING; idempotent.
6. WA opt-in seller/kurir, outbox de-dupe, retry max 3, tanpa bocor telepon pembeli
   ke kurir yang belum ditugaskan.
7. Fungsi instalasi, perubahan rekening, dan dispatch WhatsApp diakhiri '_' agar
   tidak dapat dipanggil langsung dari google.script.run di browser.
8. TIDAK mengubah aturan kurir bebas klaim setelah pickup, jumlah order aktif tanpa batas.
9. Integrasi Meta membutuhkan WA_ACCESS_TOKEN, WA_PHONE_NUMBER_ID, WA_TEMPLATE_NAME,
   WA_SEND_MODE=LIVE_APPROVED, consent dan template disetujui. Tidak mengirim WA sebelum itu.

INSTALASI DIREKOMENDASIKAN: CODESPACES (TANPA LOGIN gh di TERMUX)
A. Di Chrome GitHub: buka repository -> Code -> Codespaces -> Create codespace on main.
B. Dalam file explorer Codespaces, upload KSB_GO_V19_SAFE_UPDATE.zip.
C. Di terminal Codespaces:
      unzip -oq KSB_GO_V19_SAFE_UPDATE.zip
      bash ksb_go_v19_release/install_codespaces.sh
D. Setelah npm test lulus, script mengirim branch baru, TIDAK ke main.
E. Buka URL compare yang tercetak -> Create pull request -> REVIEW diff & CI.
F. Setelah staging lulus dan bank + WA terverifikasi, baru merge dan jalankan GitHub Actions
   staging dulu, bukan production. Deploy Web App existing melalui update deployment yang benar.

INSTALASI TERMUX (jika Github CLI nantinya berhasil login)
1. Pastikan repositori disinkronkan dan tidak ada perubahan lokal penting.
2. unzip -oq /sdcard/Download/KSB_GO_V19_SAFE_UPDATE.zip -d "$HOME"
3. bash "$HOME/ksb_go_v19_release/install_termux.sh"
   Ini mencoba GitHub CLI dan tidak menyentuh production. Jika login gagal, gunakan Codespaces.

PENGATURAN DI APPS SCRIPT (HANYA PEMILIK)
Jalankan ksbV19ConfigureBcaBank_() melalui IDE Apps Script di lingkungan tepat
setelah memverifikasi kepemilikan rekening dan legalitas penerimaan pembayaran.
Jalankan ksbV19InstallNotifications_() untuk membuat sheet outbox + trigger.
WA Graph API template punya 2 BODY placeholder tekstual. Jangan pernah commit token OAuth
atau Meta ke GitHub; gunakan Script Properties.
WA_ADMIN_OPT_IN=1 dan ADMIN_WHATSAPP=<nomor disetujui admin> mengaktifkan tujuan admin.
WA_SEND_MODE tetap DISABLED sampai izin dan uji Meta selesai.

CEK UAT WAJIB SEBELUM RILIS
- Pembeli login -> tombol Beli -> keranjang 1 qty / qty input -> checkout sesuai stok;
- Checkout gagal tertutup jika COMMERCE_V10_MODE=CATALOG atau gerbang persetujuan gagal;
- Pembeli bayar BCA ke rekening resmi, upload bukti, admin memeriksa mutasi bank
  independen; tidak menyamakan bukti foto dengan uang masuk;
- Seller notifikasi hanya setelah PAID, tidak terkirim dobel pada verifikasi ulang;
- Seller READY -> kurir online-verified yang opt-in mendapat pesan tanpa data pembeli;
- Kurir klaim atomik dan pickup, tidak membatasi total order aktif pasca pickup;
- Klaim seller/kurir dari order yang benar-benar selesai -> WA admin satu kali;
- Admin mark payout PAID hanya setelah transfer bank dan reconciliation;
- WA disable / opt-out / nomor invalid / Meta HTTP 4xx/5xx -> transaksi tetap utuh;
- Reload HP Android, pengujian semua role dan tombol; sandbox UAT tanpa uang nyata.

BATASAN
- Patch tidak membuat payment gateway resmi, tidak menebak persetujuan bank / hukum.
- WA Cloud API delivery tidak bisa 100% exactly-once saat kegagalan jaringan setelah Meta
  menerima pesan tetapi sebelum sistem mencatat id; ada retry yang bisa menyebabkan duplikat.
- Tests 100% hijau pun tidak membuktikan produksi tanpa bug. Lakukan staging manual.
- Tempel *tidak* seluruh kode atau token di chat / screenshot.
