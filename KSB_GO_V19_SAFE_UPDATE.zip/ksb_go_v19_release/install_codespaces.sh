#!/usr/bin/env bash
# Run in a GitHub Codespace opened for aryasyhptra9-spec/ksb_go_marketplace.
# NEVER deploys; only prepares a review branch and attempts a push.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$REPO_DIR" || ! -f "$REPO_DIR/package.json" || ! -f "$REPO_DIR/src/Buyer.html" ]]; then
  echo 'STOP: Buka Codespace repository KSB GO sebelum menjalankan script ini.' >&2
  exit 2
fi
if [[ "$(basename "$REPO_DIR")" != "ksb_go_marketplace" ]]; then
  echo "STOP: Repository tidak cocok: $REPO_DIR" >&2
  exit 2
fi
for command in python3 node npm git; do
  command -v "$command" >/dev/null || { echo "STOP: $command tidak tersedia" >&2; exit 2; }
done
cd "$REPO_DIR"
if [[ -n "$(git status --porcelain)" ]]; then
  # The uploaded release ZIP and extracted updater folder may exist here.
  # Do not risk clobbering any user changes, including upload artifacts.
  if git diff --quiet && git diff --cached --quiet && [[ "$(git ls-files --others --exclude-standard | grep -v -E '(^ksb_go_v19_release/|^KSB_GO_V19_SAFE_UPDATE\.zip$)' || true)" == "" ]]; then
    :
  else
    echo 'STOP: Ada perubahan sumber belum disimpan. Commit/stash dahulu.' >&2
    exit 2
  fi
fi
BRANCH="feature/ksb-go-v19-$(date -u +%Y%m%d%H%M%S)"
git switch -c "$BRANCH"
python3 "$ROOT/apply_v19.py" "$REPO_DIR"
npm test
# Only safe, intended paths are staged.
git add src/Setup.gs src/Code.gs src/CommerceV10.gs src/Index.html src/MarketplaceUIV4.html \
  src/Payments.gs src/Sellers.gs src/ManualClaimsV7.gs src/Buyer.html \
  src/NotificationsV19.gs src/PurchaseV19.html tests/v19.test.cjs
if git diff --cached --quiet; then
  echo 'Tidak ada perubahan untuk diajukan.'
  exit 0
fi
git -c user.name='KSB GO Reviewer' -c user.email='ksb-go-review@users.noreply.github.com' \
  commit -m 'feat: V19 safe checkout, verified BCA flow, consent-based WhatsApp alerts'
if git push -u origin "$BRANCH"; then
  echo "Branch berhasil dikirim: $BRANCH"
  echo "Buka: https://github.com/aryasyhptra9-spec/ksb_go_marketplace/compare/main...$BRANCH?expand=1"
else
  echo 'Push ditolak atau izin tidak tersedia. Branch lokal aman, belum mengubah main.' >&2
  echo "Branch: $BRANCH" >&2
  exit 3
fi
