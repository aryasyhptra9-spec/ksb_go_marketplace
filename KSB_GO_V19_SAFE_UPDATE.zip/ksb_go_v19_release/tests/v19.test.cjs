'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const root=path.join(__dirname,'..','src');
const src=name=>fs.readFileSync(path.join(root,name),'utf8');

function env(){
 const rows={USERS:[],SELLERS:[],SELLER_STORES:[],COURIERS:[],ORDERS:[],SELLER_ORDERS:[],DELIVERY_ORDERS:[],PAYMENTS:[],MANUAL_CLAIMS_V7:[]};
 const sheets={};
 const props={};
 const calls=[];
 const sheet=name=>({
   getLastRow:()=>sheets[name]?.length?2:0,
   getLastColumn:()=>sheets[name]?.length||0,
   getRange:()=>({setValues:vals=>{sheets[name]=vals[0];},setFrozenRows:()=>{},getDisplayValues:()=>[sheets[name]||[]]}),
   setFrozenRows:()=>{}
 });
 const fakeBook={getSheetByName:n=>sheets[n]?sheet(n):null,insertSheet:n=>{sheets[n]=[];rows[n]??=[];return sheet(n);}};
 const ctx={
  console:{error:()=>{}},Date,JSON,Number,String,Array,Object,Set,RegExp,
  KSB_CFG:{TZ:'Asia/Makassar'},
  Utilities:{formatDate:d=>new Date(d).toISOString()},
  ksbV10Enabled_:()=>false,
  ksbV10Mode_:()=>props.COMMERCE_V10_MODE||'INTERNAL_UAT',
  PropertiesService:{getScriptProperties:()=>({setProperties:(o)=>Object.assign(props,o)})},
  ScriptApp:{getProjectTriggers:()=>[],newTrigger:()=>({timeBased:()=>({everyMinutes:()=>({create:()=>{}})})})},
  UrlFetchApp:{fetch:(url,options)=>{calls.push({url,options});return {getResponseCode:()=>200,getContentText:()=>JSON.stringify({messages:[{id:'wamid.test'}]})};}},
  ksbBook_:()=>fakeBook,
  ksbWithLock_:fn=>fn(),
  ksbNow_:()=>new Date().toISOString(),
  ksbProperty_:(n,f='')=>Object.hasOwn(props,n)?props[n]:f,
  ksbSha_:s=>crypto.createHash('sha256').update(String(s)).digest('hex'),
  ksbRequire_:(ok,m)=>{if(!ok)throw Error(m||'Invalid');},
  ksbBool_:v=>v===true||v==='TRUE'||v==='true',
  ksbString_:(x,max=300)=>{const s=String(x??'').trim();if(s.length>max)throw Error('Long');return s;},
  ksbJson_:(x,df)=>{try{return JSON.parse(x);}catch{return df;}},
  ksbRow_:(n,id)=>(rows[n]||[]).find(r=>r.id===id)||null,
  ksbRows_:n=>(rows[n]||[]).map(x=>({...x})),
  ksbFilter_:(n,fn)=>(rows[n]||[]).filter(fn),
  ksbAppend_:(n,data)=>{rows[n]??=[]; rows[n].push({...data});return data;},
  ksbPatch_:(n,id,patch)=>{const r=(rows[n]||[]).find(x=>x.id===id);if(!r)throw Error('missing row');Object.assign(r,patch);return r;},
 };
 vm.createContext(ctx);
 vm.runInContext(src('NotificationsV19.gs'),ctx,{filename:'NotificationsV19.gs'});
 return {ctx,rows,props,calls};
}

test('requested BCA account configured without dropping leading zero or enabling live mode',()=>{
 const {ctx,props}=env();
 ctx.ksbV19ConfigureBcaBank_();
 assert.equal(props.BANK_NAME,'BCA');
 assert.equal(props.BANK_NUMBER,'0561934877');
 assert.equal(props.BANK_HOLDER,'Arya Syah Putra');
});

test('seller gets exactly one opt-in alert after verified payment, not before',()=>{
 const {ctx,rows}=env();ctx.ksbV19InstallNotifications_();
 rows.USERS.push({id:'U1',phone:'081234567890'});
 rows.SELLERS.push({id:'S1',user_id:'U1',verified:'TRUE'});
 rows.SELLER_STORES.push({id:'STORE1',seller_id:'S1',whatsapp:'081234567890'});
 rows.ORDERS.push({id:'O1',payment_status:'WAITING_TRANSFER'});
 rows.PAYMENTS.push({id:'P1',order_id:'O1',status:'PENDING'});
 rows.SELLER_ORDERS.push({id:'SO1',order_id:'O1',store_id:'STORE1',status:'NEW'});
 ctx.ksbV19OptInSet_({id:'U1'},{enabled:true});
 ctx.ksbV19NotifySellerPayment_('P1');assert.equal((rows.WA_OUTBOX_V19||[]).length,0);
 rows.PAYMENTS[0].status='VERIFIED';rows.ORDERS[0].payment_status='PAID';
 ctx.ksbV19NotifySellerPayment_('P1');ctx.ksbV19NotifySellerPayment_('P1');
 assert.equal(rows.WA_OUTBOX_V19.length,1);
 assert.equal(rows.WA_OUTBOX_V19[0].phone,'6281234567890');
});

test('couriers only alerted after READY and only online verified opt-ins',()=>{
 const {ctx,rows}=env();ctx.ksbV19InstallNotifications_();
 rows.USERS.push({id:'U1',phone:'081234567890'},{id:'U2',phone:'081234567891'});
 rows.COURIERS.push({id:'C1',user_id:'U1',verified:'TRUE',online:'TRUE',phone:'081234567890'},
                     {id:'C2',user_id:'U2',verified:'TRUE',online:'FALSE',phone:'081234567891'});
 rows.SELLER_ORDERS.push({id:'SO1',order_id:'O1',delivery_id:'D1'});
 rows.ORDERS.push({id:'O1',payment_status:'PAID'});
 rows.DELIVERY_ORDERS.push({id:'D1',order_id:'O1',status:'WAITING_SELLER',recipient_phone:'SECRET'});
 ctx.ksbV19OptInSet_({id:'U1'},{enabled:true});ctx.ksbV19OptInSet_({id:'U2'},{enabled:true});
 ctx.ksbV19NotifyCourierReady_('SO1');assert.equal((rows.WA_OUTBOX_V19||[]).length,0);
 rows.DELIVERY_ORDERS[0].status='AVAILABLE';
 ctx.ksbV19NotifyCourierReady_('SO1');
 assert.equal(rows.WA_OUTBOX_V19.length,1);
 assert.equal(rows.WA_OUTBOX_V19[0].user_id,'U1');
 assert.ok(!JSON.stringify(rows.WA_OUTBOX_V19[0]).includes('SECRET'));
});

test('admin claim alert requires explicit admin opt-in and valid number',()=>{
 const {ctx,rows,props}=env();ctx.ksbV19InstallNotifications_();
 rows.MANUAL_CLAIMS_V7.push({id:'CLAIM1',status:'PENDING',party_type:'SELLER',total:35000});
 props.ADMIN_WHATSAPP='081234567890';
 ctx.ksbV19NotifyAdminClaim_('CLAIM1');assert.equal(rows.WA_OUTBOX_V19.length,0);
 props.WA_ADMIN_OPT_IN='1';ctx.ksbV19NotifyAdminClaim_('CLAIM1');
 assert.equal(rows.WA_OUTBOX_V19.length,1);
 assert.equal(rows.WA_OUTBOX_V19[0].event_type,'ADMIN_CLAIM');
});

test('approved template dispatch with no live data, dedupes and preserves status',()=>{
 const {ctx,rows,props,calls}=env();ctx.ksbV19InstallNotifications_();
 rows.USERS.push({id:'U1',phone:'081234567890'});
 ctx.ksbV19OptInSet_({id:'U1'},{enabled:true});
 ctx.ksbV19Queue_('TEST','T1',[{user_id:'U1',phone:'081234567890'}],'Tes','T1');
 assert.equal(ctx.ksbV19DispatchNotifications_().status,'WAITING_WHATSAPP_BUSINESS_CONFIG');
 props.WA_ACCESS_TOKEN='SYNTHETIC_TEST_TOKEN';props.WA_PHONE_NUMBER_ID='123456789';props.WA_TEMPLATE_NAME='ksb_go_alert_v19';
 props.WA_SEND_MODE='LIVE_APPROVED';props.COMMERCE_V10_MODE='LIVE_APPROVED';
 const r=ctx.ksbV19DispatchNotifications_();assert.equal(r.sent,1);
 assert.equal(rows.WA_OUTBOX_V19[0].status,'SENT');
 assert.equal(calls.length,1);
 const body=JSON.parse(calls[0].options.payload);
 assert.equal(body.type,'template');assert.equal(body.to,'6281234567890');
 assert.equal(ctx.ksbV19DispatchNotifications_().sent,0);
});

test('frontend buy handlers exist, gate inactive checkout, and call cart/add when enabled',async()=>{
 const js=src('PurchaseV19.html').match(/<script>([\s\S]*?)<\/script>/)[1];
 const ev=[];
 const KSB={state:{user:{id:'1'},config:{checkoutEnabled:false},selectedItems:new Set()},actions:{},
   toast:(x)=>ev.push(['toast',x]),goto:async v=>ev.push(['goto',v]),
   call:async (action,args)=>{ev.push(['call',action,args]);return {items:action==='cart.get'?[]:[{id:'CI1',product_id:'P1'}]};},
   seller:async()=>'',courier:async()=>'',refresh:async()=>{}};
 const vmCtx={KSB,window:{KSB},document:{getElementById:()=>({value:'2',max:'10'})},Set,Number};
 vm.runInNewContext(js,vmCtx);
 const el={dataset:{id:'P1'},disabled:false};
 await KSB.actions.marketCardBuy(el);assert.equal(ev.filter(x=>x[0]==='call').length,0);
 KSB.state.config.checkoutEnabled=true;await KSB.actions.buyNow(el);
 assert.equal(ev.find(x=>x[0]==='call'&&x[1]==='cart.add')[2].quantity,2);
 assert.equal(KSB.state.selectedItems.has('CI1'),true);
 assert.ok(ev.some(x=>x[0]==='goto'&&x[1]==='checkout'));
 assert.equal(el.disabled,false);
});

test('V19 backend hooks are wired at the verified/ready/claim transitions',t=>{
 if(!fs.existsSync(path.join(root,'Payments.gs')))return t.skip('Run against the patched full KSB GO repository');
 assert.match(src('Payments.gs'),/ksbV19NotifySellerPayment_\(args\.paymentId\)/);
 assert.match(src('Sellers.gs'),/ksbV19NotifyCourierReady_\(args\.id\)/);
 assert.match(src('ManualClaimsV7.gs'),/ksbV19NotifyAdminClaim_\(result\.id\)/);
 assert.match(src('Code.gs'),/'notify\.optin\.set':ksbV19OptInSet_/);
 assert.match(src('Index.html'),/include_\('PurchaseV19'\)/);
});


test('owner-only installer, account update and worker are private Apps Script entry points',()=>{
 const js=src('NotificationsV19.gs');
 assert.match(js,/function ksbV19InstallNotifications_\(/);
 assert.match(js,/function ksbV19ConfigureBcaBank_\(/);
 assert.match(js,/function ksbV19DispatchNotifications_\(/);
 assert.doesNotMatch(js,/function ksbV19ConfigureBcaBank\(/);
 assert.doesNotMatch(js,/function ksbV19DispatchNotifications\(/);
});

test('no alert sent after consent is withdrawn; recipient invalid phone rejected',()=>{
 const {ctx,rows,props,calls}=env();ctx.ksbV19InstallNotifications_();
 rows.USERS.push({id:'U1',phone:'081234567890'});
 ctx.ksbV19OptInSet_({id:'U1'},{enabled:true});
 ctx.ksbV19Queue_('S1','T1',[{user_id:'U1',phone:'notaphone'}],'A','T1');
 assert.equal(rows.WA_OUTBOX_V19.length,0);
 ctx.ksbV19Queue_('S1','T1',[{user_id:'U1',phone:'081234567890'}],'A','T1');
 ctx.ksbV19OptInSet_({id:'U1'},{enabled:false});
 props.WA_ACCESS_TOKEN='SYNTHETIC_TEST_TOKEN';props.WA_PHONE_NUMBER_ID='123456789';props.WA_TEMPLATE_NAME='ksb_go_alert_v19';
 props.WA_SEND_MODE='LIVE_APPROVED';props.COMMERCE_V10_MODE='LIVE_APPROVED';
 const res=ctx.ksbV19DispatchNotifications_();
 assert.equal(res.sent,0);assert.equal(calls.length,0);assert.equal(rows.WA_OUTBOX_V19[0].status,'CANCELLED');
});

test('notification failure does not mutate order or payment rows',()=>{
 const {ctx,rows}=env();ctx.ksbV19InstallNotifications_();
 rows.ORDERS.push({id:'O1',status:'CONFIRMED',payment_status:'PAID'});
 rows.PAYMENTS.push({id:'P1',status:'VERIFIED',order_id:'O1'});
 rows.SELLER_ORDERS.push({id:'SO1',order_id:'O1',store_id:'STORE1'});
 const copy1=JSON.stringify(rows.ORDERS),copy2=JSON.stringify(rows.PAYMENTS);
 ctx.ksbV19SafeQueue_(()=>{throw Error('Simulated outbound failure')});
 assert.equal(JSON.stringify(rows.ORDERS),copy1);
 assert.equal(JSON.stringify(rows.PAYMENTS),copy2);
});

test('stock unavailable buttons disabled and checkout status remains governed by backend',()=>{
 const m=fs.readFileSync(path.join(__dirname,'..','apply_v19.py'),'utf8');
 assert.match(m,/Stok habis/);
 assert.match(m,/checkoutEnabled/);
 assert.doesNotMatch(src('PurchaseV19.html'),/checkoutEnabled\s*=\s*true/);
});
