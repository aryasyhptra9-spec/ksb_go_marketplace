#!/data/data/com.termux/files/usr/bin/bash
# KSB GO V19: create an isolated PR, run tests. Never deploy to Apps Script.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="aryasyhptra9-spec/ksb_go_marketplace"
TARGET="$HOME/ksb-go-v19-review"
BRANCH="feature/beli-bca-whatsapp-v19-$(date +%Y%m%d%H%M%S)"
for app in gh git python node npm; do
  if ! command -v "$app" >/dev/null 2>&1; then echo "Perintah $app belum tersedia. Instal melalui pkg install gh git python nodejs-lts -y";exit 1;fi
done
if ! gh auth status >/dev/null 2>&1; then
  echo 'Login GitHub sekali melalui browser perangkat (jangan kirim token ke chat).'
  gh auth login --hostname github.com --git-protocol https --web
fi
gh auth setup-git
if [ -e "$TARGET" ]; then
  echo "STOP: Folder $TARGET sudah ada. Simpan backup atau rename folder itu sebelum melanjutkan."
  exit 1
fi
gh repo clone "$REPO" "$TARGET" -- --depth 1
cd "$TARGET"
git switch -c "$BRANCH"
python "$ROOT/apply_v19.py" "$TARGET"
node --version
npm test
if [ -n "$(git status --porcelain)" ]; then
  LOGIN="$(gh api user --jq '.login')"
  git -c user.name="$LOGIN" -c user.email="$LOGIN@users.noreply.github.com" add src tests
  git -c user.name="$LOGIN" -c user.email="$LOGIN@users.noreply.github.com" commit -m 'feat: verified buy flow, BCA bank settings, opted-in WhatsApp notifications'
  git push -u origin "$BRANCH"
  gh pr create --base main --head "$BRANCH" \
    --title 'KSB GO V19: tombol Beli, rekening BCA, WhatsApp notifikasi' \
    --body 'PERLU REVIEW dan UJI STAGING sebelum merge/deploy. Pembayaran tetap fail-closed. WhatsApp Cloud API membutuhkan konfigurasi, template Meta yang disetujui, dan persetujuan penerima. Tidak ada deployment production otomatis.'
fi
echo 'Selesai: patch sudah diajukan lewat Pull Request. Jangan jalankan deployment production sebelum verifikasi staging dan Meta.'
