/** KSB GO V19 — consent-based WhatsApp Business Cloud API notifications.
 * Notifications are advisory only. They never change payment, order, or invoice status.
 * Requires a Meta-approved template with two BODY text placeholders:
 *  "KSB GO: {{1}}. Referensi: {{2}}. Buka aplikasi KSB GO untuk detail."
 */
var KSB_V19_OUTBOX = 'WA_OUTBOX_V19';
var KSB_V19_OPTINS = 'WA_OPT_INS_V19';
var KSB_V19_OUTBOX_HEADERS = 'id,event_type,entity_id,user_id,phone,param1,param2,status,attempts,provider_id,last_error,created_at,updated_at';
var KSB_V19_OPTINS_HEADERS = 'id,user_id,enabled,updated_at';

function ksbV19EnsureTables_(){
  var book=ksbBook_();
  [{name:KSB_V19_OUTBOX,headers:KSB_V19_OUTBOX_HEADERS},{name:KSB_V19_OPTINS,headers:KSB_V19_OPTINS_HEADERS}].forEach(function(x){
    var sh=book.getSheetByName(x.name)||book.insertSheet(x.name);
    var heads=x.headers.split(',');
    if(sh.getLastRow()===0){
      sh.getRange(1,1,1,heads.length).setValues([heads]);
      sh.setFrozenRows(1);
    } else {
      var existing=sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0];
      ksbRequire_(existing.join(',')===heads.join(','),'Skema '+x.name+' tidak cocok; hentikan dan audit migrasi.');
    }
  });
}

/** Execute once by project owner in the STAGING project. Does not enable live trade. */
function ksbV19InstallNotifications_(){
  ksbV19EnsureTables_();
  var handler='ksbV19DispatchNotifications_';
  if(!ScriptApp.getProjectTriggers().some(function(t){return t.getHandlerFunction()===handler;})){
    ScriptApp.newTrigger(handler).timeBased().everyMinutes(5).create();
  }
  return {ready:true,template:'ksb_go_alert_v19',autoSendConfigured:ksbV19CloudReady_()};
}

/** Explicit owner operation. This sets the requested buyer receiving account only.
 * Requires separate authorization, account ownership verification, and live-mode gates.
 * DO NOT use production payment credentials or production DB in staging.
 */
function ksbV19ConfigureBcaBank_(){
  // Operator-only (private Apps Script entrypoint).
  // Verify the receiving account belongs to the authorized business before LIVE mode.
  PropertiesService.getScriptProperties().setProperties({
    BANK_NAME:'BCA',
    BANK_NUMBER:'0561934877',
    BANK_HOLDER:'Arya Syah Putra'
  },false);
  return {bank:'BCA',lastFour:'4877',holder:'Arya Syah Putra',checkoutEnabled:ksbV10Enabled_()};
}

function ksbV19OptId_(userId){return 'WAOPT_'+ksbSha_(String(userId)).slice(0,24);}
function ksbV19HasOptIn_(userId){
  if(!userId)return false;
  var row=ksbRow_(KSB_V19_OPTINS,ksbV19OptId_(userId));
  return !!row&&ksbBool_(row.enabled);
}
function ksbV19OptInGet_(actor){
  ksbRequire_(actor&&actor.id,'Akun belum login.');
  ksbV19EnsureTables_();
  return {enabled:ksbV19HasOptIn_(actor.id),hasPhone:!!(ksbRow_('USERS',actor.id)||{}).phone};
}
function ksbV19OptInSet_(actor,args){
  ksbRequire_(actor&&actor.id,'Akun belum login.');
  ksbRequire_(args&&typeof args.enabled==='boolean','Persetujuan WhatsApp tidak valid.');
  return ksbWithLock_(function(){
    ksbV19EnsureTables_();
    var id=ksbV19OptId_(actor.id),old=ksbRow_(KSB_V19_OPTINS,id);
    if(old)ksbPatch_(KSB_V19_OPTINS,id,{enabled:args.enabled?'TRUE':'FALSE',updated_at:ksbNow_()});
    else ksbAppend_(KSB_V19_OPTINS,{id:id,user_id:actor.id,enabled:args.enabled?'TRUE':'FALSE',updated_at:ksbNow_()});
    return {enabled:args.enabled};
  });
}
function ksbV19SafeQueue_(fn){
  try{fn();}catch(e){console.error('KSB V19 WhatsApp outbox error: '+String(e&&e.message||'error'));}
}
function ksbV19NormalizePhone_(value){
  var p=String(value||'').replace(/\D/g,'');
  if(p.slice(0,1)==='0')p='62'+p.slice(1);
  else if(p.slice(0,1)==='8')p='62'+p;
  return /^62[0-9]{8,13}$/.test(p)?p:'';
}
function ksbV19Queue_(eventType,entityId,recipients,param1,param2){
  ksbV19EnsureTables_();
  return ksbWithLock_(function(){
    var count=0;
    recipients.forEach(function(rec){
      var phone=ksbV19NormalizePhone_(rec.phone),userId=String(rec.user_id||'');
      if(!phone||!userId)return;
      if(userId==='ADMIN_CONFIG'){
        if(ksbProperty_('WA_ADMIN_OPT_IN','0')!=='1')return;
      }else if(!ksbV19HasOptIn_(userId))return;
      var id='WA_'+ksbSha_(eventType+'|'+entityId+'|'+userId).slice(0,30);
      if(ksbRow_(KSB_V19_OUTBOX,id))return;
      ksbAppend_(KSB_V19_OUTBOX,{
        id:id,event_type:eventType,entity_id:entityId,user_id:userId,phone:phone,
        param1:ksbString_(param1,150),param2:ksbString_(param2,120),status:'PENDING',attempts:0,
        provider_id:'',last_error:'',created_at:ksbNow_(),updated_at:ksbNow_()
      });
      count++;
    });
    return count;
  });
}

/** Notify seller for verified transfer, not merely for unpaid checkout. */
function ksbV19NotifySellerPayment_(paymentId){
  var pay=ksbRow_('PAYMENTS',paymentId);
  var order=pay&&ksbRow_('ORDERS',pay.order_id);
  if(!pay||pay.status!=='VERIFIED'||!order||order.payment_status!=='PAID')return;
  ksbFilter_('SELLER_ORDERS',function(so){return so.order_id===order.id&&so.status!=='REJECTED';}).forEach(function(so){
    var store=ksbRow_('SELLER_STORES',so.store_id),seller=store&&ksbRow_('SELLERS',store.seller_id);
    var user=seller&&ksbRow_('USERS',seller.user_id);
    if(!seller||!user||!ksbBool_(seller.verified))return;
    ksbV19Queue_('SELLER_PAID',so.id,[{user_id:user.id,phone:store.whatsapp||user.phone}],
      'Ada pesanan baru yang sudah dibayar untuk toko Anda',so.id);
  });
}

/** No address or buyer phone is disclosed to an unassigned courier. */
function ksbV19NotifyCourierReady_(sellerOrderId){
  var so=ksbRow_('SELLER_ORDERS',sellerOrderId);
  var delivery=so&&ksbRow_('DELIVERY_ORDERS',so.delivery_id);
  var order=so&&ksbRow_('ORDERS',so.order_id);
  if(!so||!delivery||delivery.status!=='AVAILABLE'||!order||order.payment_status!=='PAID')return;
  var recipients=ksbFilter_('COURIERS',function(c){return ksbBool_(c.verified)&&ksbBool_(c.online);}).map(function(c){
    var u=ksbRow_('USERS',c.user_id);
    return {user_id:c.user_id,phone:c.phone||(u&&u.phone)||''};
  });
  ksbV19Queue_('COURIER_AVAILABLE',delivery.id,recipients,
    'Ada pengiriman baru tersedia untuk diklaim',delivery.id);
}

function ksbV19NotifyAdminClaim_(claimId){
  var claim=ksbRow_('MANUAL_CLAIMS_V7',claimId);
  if(!claim||claim.status!=='PENDING')return;
  var phone=ksbProperty_('ADMIN_WHATSAPP','');
  ksbV19Queue_('ADMIN_CLAIM',claim.id,[{user_id:'ADMIN_CONFIG',phone:phone}],
    'Tagihan baru '+claim.party_type+' Rp'+Number(claim.total).toLocaleString('id-ID'),claim.id);
}
function ksbV19CloudReady_(){
  return ksbProperty_('WA_SEND_MODE','DISABLED')==='LIVE_APPROVED' && ksbV10Mode_()==='LIVE_APPROVED' &&
    !!(ksbProperty_('WA_ACCESS_TOKEN')&&ksbProperty_('WA_PHONE_NUMBER_ID')&&ksbProperty_('WA_TEMPLATE_NAME'));
}
function ksbV19DispatchNotifications_(){
  ksbV19EnsureTables_();
  if(!ksbV19CloudReady_())return {status:'WAITING_WHATSAPP_BUSINESS_CONFIG',sent:0};
  // Claim rows under lock, but never hold the lock during outbound network I/O.
  var batch=ksbWithLock_(function(){
    var now=ksbNow_();
    var rows=ksbRows_(KSB_V19_OUTBOX).filter(function(r){
      var tries=Number(r.attempts)||0;
      return (r.status==='PENDING' || (r.status==='RETRY'&&tries<3) ||
        (r.status==='SENDING'&&String(r.updated_at||'')<Utilities.formatDate(new Date(Date.now()-20*60*1000),KSB_CFG.TZ,"yyyy-MM-dd'T'HH:mm:ssXXX")&&tries<3));
    }).slice(0,8);
    rows.forEach(function(r){ksbPatch_(KSB_V19_OUTBOX,r.id,{status:'SENDING',attempts:(Number(r.attempts)||0)+1,updated_at:now});});
    return rows;
  });
  var sent=0,failed=0;
  batch.forEach(function(r){
    // Recheck opt-in at delivery time. Admin opted in through Script Properties.
    var consent=r.user_id==='ADMIN_CONFIG'?ksbProperty_('WA_ADMIN_OPT_IN','0')==='1':ksbV19HasOptIn_(r.user_id);
    if(!consent){ksbPatch_(KSB_V19_OUTBOX,r.id,{status:'CANCELLED',updated_at:ksbNow_()});return;}
    try{
      var receipt=ksbV19CloudSend_(r);
      ksbPatch_(KSB_V19_OUTBOX,r.id,{status:'SENT',provider_id:receipt,updated_at:ksbNow_(),last_error:''});
      sent++;
    }catch(e){
      var attempts=(Number(r.attempts)||0)+1;
      ksbPatch_(KSB_V19_OUTBOX,r.id,{status:attempts>=3?'FAILED':'RETRY',last_error:ksbString_(String(e&&e.message||'Send failed').slice(0,140),150),updated_at:ksbNow_()});
      failed++;
    }
  });
  return {status:'COMPLETE',attempted:batch.length,sent:sent,failed:failed};
}
function ksbV19CloudSend_(row){
  var version=ksbProperty_('WA_GRAPH_VERSION','v24.0');
  ksbRequire_(/^v\d+\.0$/.test(version),'WA_GRAPH_VERSION invalid');
  var phoneId=ksbProperty_('WA_PHONE_NUMBER_ID');
  ksbRequire_(/^\d{5,30}$/.test(phoneId),'WA_PHONE_NUMBER_ID tidak valid');
  var template=ksbProperty_('WA_TEMPLATE_NAME','');
  ksbRequire_(/^[a-z0-9_]{1,512}$/.test(template),'WA_TEMPLATE_NAME tidak valid');
  var language=ksbProperty_('WA_TEMPLATE_LANGUAGE','id');
  ksbRequire_(/^[a-z]{2,3}(_[A-Z]{2})?$/.test(language),'WA_TEMPLATE_LANGUAGE tidak valid');
  var endpoint='https://graph.facebook.com/'+version+'/'+phoneId+'/messages';
  var payload={messaging_product:'whatsapp',to:row.phone,type:'template',template:{
    name:template,language:{code:language},
    components:[{type:'body',parameters:[{type:'text',text:row.param1},{type:'text',text:row.param2}]}]
  }};
  var result=UrlFetchApp.fetch(endpoint,{method:'post',contentType:'application/json',
    headers:{Authorization:'Bearer '+ksbProperty_('WA_ACCESS_TOKEN')},
    payload:JSON.stringify(payload),muteHttpExceptions:true});
  var status=result.getResponseCode();
  if(status<200||status>=300)throw Error('WA API HTTP '+status);
  var body=ksbJson_(result.getContentText(),{});
  ksbRequire_(body.messages&&body.messages[0]&&body.messages[0].id,'WA API tidak mengembalikan message id');
  return String(body.messages[0].id).slice(0,120);
}
