# KSB GO V19 — Status validasi (2026-10-26)

## Base & scope
- Repository: `aryasyhptra9-spec/ksb_go_marketplace`, branch `main`, source V17.2.
- Manifest inspected via connected GitHub repository, and all 18 original source anchor strings validated at source snapshot.
- Release is a guarded source *patch*, **not** a full clone or a deployed service.
- Source write access through ChatGPT's GitHub integration returned HTTP 403. No repository writes were made.

## Local checks performed
- Python syntax on `apply_v19.py`: PASS.
- Shell syntax on both installers: PASS.
- Node syntax on tests: PASS.
- Guarded patcher applied to a controlled fixture containing exactly 18 source anchors: PASS.
- 11 Node.js simulated notification/purchase tests: 10 PASSED, 1 SKIPPED until tested on complete repository.
- Production integration tests, Meta Cloud API delivery, Google Apps Script deployment: NOT RUN.

## Required gates before enabling financial transactions
1. Run all source tests on real cloned repository; inspect exact GitHub diff and status checks.
2. Run Apps Script staging only, backup remote; never use production spreadsheet for synthetic payments.
3. Set BANK_* Script Properties only after business/bank-owner authorization confirmed.
4. Verify statement independently; customer-uploaded payment image alone is not proof of receipt.
5. Do not activate `COMMERCE_V10_MODE=LIVE_APPROVED` without security/legal/refund/reconciliation acceptance.
6. Use Meta-approved WA template, consent capture, opt-out, valid business phone number ID and token; ensure no double notification under retry/races.
7. Exercise all roles and delivery flows, including courier free claims after pickup.
8. Note: Meta may accept a WhatsApp message then timeout without acknowledgment; retry can duplicate an actual message. Outbox dedupe prevents duplicate enqueue, not exactly-once external delivery.
9. Do not represent system as production-ready until end-to-end UAT checks are signed off.

## Install options
- Browser preferred: GitHub Codespaces, upload ZIP and run `bash ksb_go_v19_release/install_codespaces.sh`.
- Termux optional: `bash "$HOME/ksb_go_v19_release/install_termux.sh"`, needs authenticated `gh` CLI. Not recommended while device login is failing.
